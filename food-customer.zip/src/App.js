//import Bt from './Bt';
import logo from './logo.svg';
// import './App.css';

import 'bootstrap/dist/css/bootstrap.min.css'

// import MyNavBar from './MyNavBar.js';
import CustomersRoute from './CustomersRoute.js';
// import MuDemo from './MuDemo.js';
// import DarkLight from './DarkLight';
// import Dark from './Dark';
// import Logins from './Logins';
// import Login from './Login';

function App() {
  return (
    <div>
      {/* <MyNavBar /> */}

      <CustomersRoute/>
      {/* <MuDemo /> */}
      {/* <DarkLight/> */}
      {/* <Dark/> */}
      {/* <Logins/> */}
      {/* <Login/> */}
      {/* <Bt/> */}
    </div>
  );
}

export default App;
