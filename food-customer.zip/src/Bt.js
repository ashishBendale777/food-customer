import React from 'react'
import './Bt.css'
const Bt = () => {
  return (
    <div>
        <button class="dark-button">Click me</button>
</div>
  )
}

export default Bt