import React from 'react'

const AboutUs = () => {
    return (
        <div>
            <h4>AboutUs</h4>
        </div>
    )
}

export default AboutUs