import React from "react";
import '../CSS/Foods.css'
const Foods = () => {
  return (
    <div>
      <h4>Foods</h4>
    </div>
  );
};

export default Foods;
