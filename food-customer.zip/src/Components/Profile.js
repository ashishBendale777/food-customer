import React from 'react'
import '../CSS/Profile.css'

const Profile = () => {
    return (
        <div className='text'>
            <h4>Profile</h4>
        </div>
    )
}

export default Profile