import React from 'react'
import './MyNavBar.css'
const NavBar = () => {
  return (
    <div></div>
  )
}

export default NavBar