import React from 'react'

const MuDemo = () => {
    return (
        <div>
            <div className='box1'>rgft</div>
            <div className='box2'>dfg</div>
        </div>
    )
}

export default MuDemo