import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  UserData: {},
  isRegister: false,
  isLogin: false,
};

const UserSlice = createSlice({
  initialState,
  name: "user",
  reducers: {
    login: (state) => {
      state.isLogin = true;
    },

    register: (state, action) => {
      state.UserData = action.payload;
      state.isRegister = true;
    },
    
    logout: (state) => {
      state.isLogin = false;
    },
  },
});

export const { login, register, logout } = UserSlice.actions;
export default UserSlice.reducer;
